
import { Button } from '@/components/ui/button';
import { Sun, Zap, Leaf } from 'lucide-react';

const SolutionsSection = () => {
  const solutions = [
    {
      icon: Sun,
      title: "Residential Solar",
      description: "Transform your home into an energy-efficient powerhouse with our custom residential solar solutions.",
      features: ["Rooftop Installation", "Energy Storage", "Smart Monitoring", "25-Year Warranty"],
      image: "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=400&h=300&fit=crop"
    },
    {
      icon: Zap,
      title: "Commercial Solar",
      description: "Reduce operational costs and boost your business's sustainability with scalable commercial solar systems.",
      features: ["Large-Scale Installation", "Grid Integration", "Performance Analytics", "Tax Benefits"],
      image: "https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=400&h=300&fit=crop"
    },
    {
      icon: Leaf,
      title: "Utility-Scale Solar",
      description: "Partner with us for mega solar projects that power communities and drive the renewable energy transition.",
      features: ["MW Scale Projects", "Grid Infrastructure", "Project Management", "Government Partnerships"],
      image: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=400&h=300&fit=crop"
    }
  ];

  return (
    <section id="solutions" className="py-20 bg-gradient-to-br from-nature-beige/30 to-primary-light/10">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 font-poppins">
              Our <span className="text-primary">Solar Solutions</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto font-poppins">
              Comprehensive solar energy solutions tailored to your unique needs, from residential rooftops to utility-scale installations.
            </p>
          </div>

          {/* Solutions Grid */}
          <div className="grid lg:grid-cols-3 gap-8 mb-16">
            {solutions.map((solution, index) => (
              <div 
                key={index} 
                className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 group"
              >
                {/* Image */}
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={solution.image} 
                    alt={solution.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 left-4 bg-white/90 p-3 rounded-full">
                    <solution.icon className="h-6 w-6 text-primary" />
                  </div>
                </div>

                {/* Content */}
                <div className="p-8">
                  <h3 className="text-2xl font-semibold text-gray-900 mb-3 font-poppins">
                    {solution.title}
                  </h3>
                  <p className="text-gray-600 mb-6 leading-relaxed">
                    {solution.description}
                  </p>

                  {/* Features */}
                  <ul className="space-y-2 mb-6">
                    {solution.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center text-sm text-gray-700">
                        <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <Button 
                    className="w-full bg-primary hover:bg-primary/90 text-white"
                    onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                  >
                    Learn More
                  </Button>
                </div>
              </div>
            ))}
          </div>

          {/* Process Section */}
          <div className="bg-white rounded-2xl p-8 md:p-12 shadow-lg">
            <h3 className="text-3xl font-semibold text-gray-900 text-center mb-12 font-poppins">
              Our Simple 4-Step Process
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-primary">1</span>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Consultation</h4>
                <p className="text-gray-600 text-sm">Free site assessment and energy audit</p>
              </div>

              <div className="text-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-primary">2</span>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Design</h4>
                <p className="text-gray-600 text-sm">Custom system design and proposal</p>
              </div>

              <div className="text-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-primary">3</span>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Installation</h4>
                <p className="text-gray-600 text-sm">Professional installation by certified technicians</p>
              </div>

              <div className="text-center">
                <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-primary">4</span>
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Support</h4>
                <p className="text-gray-600 text-sm">Ongoing monitoring and maintenance</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SolutionsSection;
