
const TestimonialsSection = () => {
  const testimonials = [
    {
      name: "Rajesh Kumar",
      location: "Mumbai, Maharashtra",
      role: "Homeowner",
      image: "https://images.unsplash.com/photo-1581090464777-f3220bbe1b8b?w=100&h=100&fit=crop&crop=face",
      rating: 5,
      text: "Switching to solar with Aditya Solar Group was the best decision for our family. Our electricity bills have dropped by 90%, and we're proud to contribute to a cleaner environment. The installation team was professional and the system works flawlessly.",
      savings: "₹8,500/month"
    },
    {
      name: "Priya Sharma",
      location: "Pune, Maharashtra",
      role: "Business Owner",
      image: "https://images.unsplash.com/photo-1581090464777-f3220bbe1b8b?w=100&h=100&fit=crop&crop=face",
      rating: 5,
      text: "Our manufacturing unit has significantly reduced operational costs since installing the commercial solar system. Aditya Solar Group delivered exactly what they promised - quality, reliability, and excellent after-sales service.",
      savings: "₹45,000/month"
    },
    {
      name: "Dr. Amit Patel",
      location: "Ahmedabad, Gujarat",
      role: "Hospital Administrator",
      image: "https://images.unsplash.com/photo-1581090464777-f3220bbe1b8b?w=100&h=100&fit=crop&crop=face",
      rating: 5,
      text: "As a healthcare facility, uninterrupted power is crucial for us. The solar system with battery backup has been a game-changer. Professional installation, transparent pricing, and ongoing support - highly recommended!",
      savings: "₹25,000/month"
    }
  ];

  return (
    <section id="testimonials" className="py-20 bg-gradient-to-br from-nature-beige/50 to-white">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 font-poppins">
              What Our <span className="text-primary">Customers Say</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto font-poppins">
              Real stories from real customers who've transformed their energy consumption and saved thousands with our solar solutions.
            </p>
          </div>

          {/* Testimonials Grid */}
          <div className="grid lg:grid-cols-3 gap-8 mb-16">
            {testimonials.map((testimonial, index) => (
              <div 
                key={index} 
                className="bg-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 border border-primary/10"
              >
                {/* Rating Stars */}
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <svg 
                      key={i} 
                      className="w-5 h-5 text-yellow-400 fill-current" 
                      viewBox="0 0 20 20"
                    >
                      <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z"/>
                    </svg>
                  ))}
                </div>

                {/* Testimonial Text */}
                <p className="text-gray-700 leading-relaxed mb-6 font-poppins">
                  "{testimonial.text}"
                </p>

                {/* Savings Highlight */}
                <div className="bg-primary/5 rounded-lg p-4 mb-6">
                  <div className="text-sm text-gray-600 mb-1">Monthly Savings</div>
                  <div className="text-2xl font-bold text-primary">{testimonial.savings}</div>
                </div>

                {/* Customer Info */}
                <div className="flex items-center">
                  <img 
                    src={testimonial.image} 
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover mr-4"
                  />
                  <div>
                    <div className="font-semibold text-gray-900">{testimonial.name}</div>
                    <div className="text-sm text-gray-600">{testimonial.role}</div>
                    <div className="text-sm text-primary">{testimonial.location}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Call to Action */}
          <div className="text-center bg-primary rounded-2xl p-8 md:p-12 text-white">
            <h3 className="text-3xl font-semibold mb-4 font-poppins">
              Join Thousands of Satisfied Customers
            </h3>
            <p className="text-white/90 text-lg mb-6 max-w-2xl mx-auto">
              Start your solar journey today and become part of the clean energy revolution. 
              Get a free consultation and see how much you can save.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button 
                onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-white text-primary hover:bg-nature-beige transition-colors px-8 py-3 rounded-lg font-semibold"
              >
                Get Your Free Quote
              </button>
              <button className="border-2 border-white text-white hover:bg-white hover:text-primary transition-colors px-8 py-3 rounded-lg font-semibold">
                Schedule Site Visit
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
