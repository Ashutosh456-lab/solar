
import { Leaf, Sun, Zap } from 'lucide-react';

const AboutSection = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 font-poppins">
              About <span className="text-primary">Aditya Solar Group</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto font-poppins">
              Leading the renewable energy revolution with innovative solar solutions that harmonize technology with nature.
            </p>
          </div>

          {/* Content Grid */}
          <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
            {/* Left Column - Text */}
            <div className="space-y-6">
              <h3 className="text-3xl font-semibold text-gray-900 mb-4 font-poppins">
                Our Mission & Legacy
              </h3>
              <p className="text-lg text-gray-700 leading-relaxed">
                Founded with a vision to harness the sun's infinite energy, Aditya Solar Group has been at the forefront of India's solar revolution. We believe in creating sustainable energy solutions that not only power homes and businesses but also protect our planet for future generations.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed">
                Our commitment goes beyond just installing solar panels. We're building a community of environmentally conscious individuals and organizations who understand that the future of energy is clean, renewable, and sustainable.
              </p>
              
              {/* Key Values */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
                <div className="text-center p-4">
                  <div className="bg-primary/10 p-3 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                    <Sun className="h-8 w-8 text-primary" />
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2">Innovation</h4>
                  <p className="text-sm text-gray-600">Cutting-edge solar technology</p>
                </div>
                <div className="text-center p-4">
                  <div className="bg-primary/10 p-3 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                    <Leaf className="h-8 w-8 text-primary" />
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2">Sustainability</h4>
                  <p className="text-sm text-gray-600">Protecting our environment</p>
                </div>
                <div className="text-center p-4">
                  <div className="bg-primary/10 p-3 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-3">
                    <Zap className="h-8 w-8 text-primary" />
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2">Reliability</h4>
                  <p className="text-sm text-gray-600">Dependable energy solutions</p>
                </div>
              </div>
            </div>

            {/* Right Column - Image */}
            <div className="relative">
              <div className="bg-gradient-to-br from-primary to-primary-light rounded-2xl p-8 text-white">
                <img 
                  src="https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=600&h=400&fit=crop" 
                  alt="Solar panels in nature landscape" 
                  className="w-full h-64 object-cover rounded-xl mb-6"
                />
                <h4 className="text-2xl font-semibold mb-3">Our Vision</h4>
                <p className="text-white/90">
                  To be India's most trusted renewable energy partner, creating a sustainable future where clean energy powers every home and business.
                </p>
              </div>
            </div>
          </div>

          {/* Team Section */}
          <div className="text-center">
            <h3 className="text-3xl font-semibold text-gray-900 mb-8 font-poppins">
              Expert Team, Proven Results
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="bg-primary/5 p-6 rounded-xl">
                  <div className="text-3xl font-bold text-primary mb-2">10+</div>
                  <div className="text-gray-600">Years Experience</div>
                </div>
              </div>
              <div className="text-center">
                <div className="bg-primary/5 p-6 rounded-xl">
                  <div className="text-3xl font-bold text-primary mb-2">100+</div>
                  <div className="text-gray-600">Expert Engineers</div>
                </div>
              </div>
              <div className="text-center">
                <div className="bg-primary/5 p-6 rounded-xl">
                  <div className="text-3xl font-bold text-primary mb-2">24/7</div>
                  <div className="text-gray-600">Customer Support</div>
                </div>
              </div>
              <div className="text-center">
                <div className="bg-primary/5 p-6 rounded-xl">
                  <div className="text-3xl font-bold text-primary mb-2">99%</div>
                  <div className="text-gray-600">Client Satisfaction</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
