
import { Leaf, Sun, Zap } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="bg-primary p-2 rounded-full">
                <Leaf className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold font-poppins">Aditya Solar Group</span>
            </div>
            <p className="text-gray-400 leading-relaxed">
              Leading the renewable energy revolution with innovative solar solutions that harmonize technology with nature.
            </p>
            <div className="flex space-x-4">
              <div className="bg-gray-800 p-2 rounded-full hover:bg-primary transition-colors cursor-pointer">
                <Sun className="h-5 w-5" />
              </div>
              <div className="bg-gray-800 p-2 rounded-full hover:bg-primary transition-colors cursor-pointer">
                <Leaf className="h-5 w-5" />
              </div>
              <div className="bg-gray-800 p-2 rounded-full hover:bg-primary transition-colors cursor-pointer">
                <Zap className="h-5 w-5" />
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4 font-poppins">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <button 
                  onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  About Us
                </button>
              </li>
              <li>
                <button 
                  onClick={() => document.getElementById('solutions')?.scrollIntoView({ behavior: 'smooth' })}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Solar Solutions
                </button>
              </li>
              <li>
                <button 
                  onClick={() => document.getElementById('impact')?.scrollIntoView({ behavior: 'smooth' })}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Environmental Impact
                </button>
              </li>
              <li>
                <button 
                  onClick={() => document.getElementById('testimonials')?.scrollIntoView({ behavior: 'smooth' })}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  Customer Stories
                </button>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-4 font-poppins">Our Services</h3>
            <ul className="space-y-3 text-gray-400">
              <li>Residential Solar Installation</li>
              <li>Commercial Solar Systems</li>
              <li>Utility-Scale Projects</li>
              <li>Solar Maintenance & Support</li>
              <li>Energy Storage Solutions</li>
              <li>Grid Integration Services</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4 font-poppins">Contact Info</h3>
            <div className="space-y-3 text-gray-400">
              <div>
                <p>56 A Trimurti Nagar</p>
                <p>Nagpur, Maharashtra 440022</p>
              </div>
              <div>
                <p>Phone: +91 7020913150</p>
                <p>Phone: +91 8793556899</p>
              </div>
              <div>
                <p>Email: adityasolargroup@gmail.com</p>
                <p>Email: adityasolargroupsales@gmail.com</p>
              </div>
              <div>
                <p className="text-sm">Mon-Sat: 9:00 AM - 6:00 PM</p>
                <p className="text-sm">Sun: 10:00 AM - 4:00 PM</p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © {currentYear} Aditya Solar Group. All rights reserved. | Powering the Future with Nature
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                Terms of Service
              </a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">
                Cookie Policy
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
