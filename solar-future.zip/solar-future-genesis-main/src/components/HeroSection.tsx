
import { Button } from '@/components/ui/button';
import { Sun, Zap, Leaf } from 'lucide-react';

const HeroSection = () => {
  const scrollToSolutions = () => {
    const element = document.getElementById('solutions');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background with gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/90 via-primary-light/80 to-nature-beige/90">
        {/* Animated background pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-32 h-32 bg-white rounded-full animate-float"></div>
          <div className="absolute top-40 right-32 w-20 h-20 bg-white rounded-full animate-float" style={{animationDelay: '1s'}}></div>
          <div className="absolute bottom-32 left-1/4 w-24 h-24 bg-white rounded-full animate-float" style={{animationDelay: '2s'}}></div>
          <div className="absolute bottom-20 right-20 w-16 h-16 bg-white rounded-full animate-float" style={{animationDelay: '0.5s'}}></div>
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center">
        <div className="max-w-4xl mx-auto">
          {/* Floating icons */}
          <div className="flex justify-center space-x-8 mb-8">
            <div className="bg-white/20 p-4 rounded-full animate-float">
              <Sun className="h-8 w-8 text-white" />
            </div>
            <div className="bg-white/20 p-4 rounded-full animate-float" style={{animationDelay: '1s'}}>
              <Leaf className="h-8 w-8 text-white" />
            </div>
            <div className="bg-white/20 p-4 rounded-full animate-float" style={{animationDelay: '2s'}}>
              <Zap className="h-8 w-8 text-white" />
            </div>
          </div>

          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 font-poppins animate-fade-in">
            Powering the Future
            <span className="block bg-gradient-to-r from-nature-beige to-white bg-clip-text text-transparent">
              with Nature
            </span>
          </h1>

          <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-3xl mx-auto animate-fade-in font-poppins font-light" style={{animationDelay: '0.3s'}}>
            Harness the sun's energy to create a cleaner, greener planet. Leading renewable energy solutions for homes, businesses, and communities.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in" style={{animationDelay: '0.6s'}}>
            <Button 
              onClick={scrollToSolutions}
              size="lg" 
              className="bg-white text-primary hover:bg-white/90 px-8 py-4 text-lg font-semibold"
            >
              Explore Our Solutions
            </Button>
            <Button 
              onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              variant="outline" 
              size="lg" 
              className="bg-white text-primary hover:bg-white/90 px-8 py-4 text-lg font-semibold"
            >
              Request Consultation
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16 animate-fade-in" style={{animationDelay: '0.9s'}}>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-white mb-2">200+</div>
              <div className="text-white/80">Projects Completed</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-white mb-2">20MW+</div>
              <div className="text-white/80">Total Capacity Installed</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-white mb-2">20k+</div>
              <div className="text-white/80">Tons CO₂ Saved</div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
