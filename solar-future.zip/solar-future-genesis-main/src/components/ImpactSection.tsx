
import { Leaf, Wind, Zap, Sun } from 'lucide-react';

const ImpactSection = () => {
  const impactStats = [
    {
      icon: Leaf,
      value: "15,000+",
      label: "Tons CO₂ Reduced",
      description: "Equivalent to planting 600,000+ trees"
    },
    {
      icon: Sun,
      value: "20MW+",
      label: "Clean Energy Generated",
      description: "Powering 6,000+ homes annually"
    },
    {
      icon: Zap,
      value: "₹1.5Cr+",
      label: "Customer Savings",
      description: "On electricity bills annually"
    },
    {
      icon: Wind,
      value: "150+",
      label: "Projects Completed",
      description: "Across residential & commercial sectors"
    }
  ];

  return (
    <section id="impact" className="py-20 bg-primary text-white">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 font-poppins">
              Our Environmental <span className="text-nature-beige">Impact</span>
            </h2>
            <p className="text-xl text-white/90 max-w-3xl mx-auto font-poppins">
              Every solar installation contributes to a cleaner, greener future. See how we're making a difference together.
            </p>
          </div>

          {/* Impact Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {impactStats.map((stat, index) => (
              <div 
                key={index} 
                className="text-center bg-white/10 backdrop-blur-sm rounded-2xl p-8 hover:bg-white/20 transition-all duration-300"
              >
                <div className="bg-white/20 p-4 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
                  <stat.icon className="h-10 w-10 text-white" />
                </div>
                <div className="text-3xl md:text-4xl font-bold mb-2 font-poppins">
                  {stat.value}
                </div>
                <div className="text-xl font-semibold mb-2 text-nature-beige">
                  {stat.label}
                </div>
                <div className="text-white/80 text-sm">
                  {stat.description}
                </div>
              </div>
            ))}
          </div>

          {/* Sustainability Initiatives */}
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Column - Content */}
            <div>
              <h3 className="text-3xl font-semibold mb-6 font-poppins">
                Leading the Green Revolution
              </h3>
              <p className="text-white/90 text-lg leading-relaxed mb-6">
                Our commitment to sustainability goes beyond solar installations. With 10+ years of experience, our expert team delivers proven results through innovative recycling programs and sustainable practices.
              </p>

              <div className="space-y-4">
                <div className="flex items-start space-x-4">
                  <div className="bg-white/20 p-2 rounded-full mt-1">
                    <Leaf className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-nature-beige mb-1">Carbon Neutral Operations</h4>
                    <p className="text-white/80 text-sm">All our facilities run on 100% renewable energy</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-white/20 p-2 rounded-full mt-1">
                    <Wind className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-nature-beige mb-1">Sustainable Manufacturing</h4>
                    <p className="text-white/80 text-sm">Eco-friendly production processes and materials</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-white/20 p-2 rounded-full mt-1">
                    <Zap className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-nature-beige mb-1">Community Programs</h4>
                    <p className="text-white/80 text-sm">Solar education and awareness initiatives</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column - Image */}
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?w=600&h=400&fit=crop" 
                alt="Green forest representing environmental impact" 
                className="w-full h-80 object-cover rounded-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent rounded-2xl"></div>
              <div className="absolute bottom-6 left-6 right-6">
                <div className="bg-white/90 backdrop-blur-sm rounded-xl p-4">
                  <div className="text-2xl font-bold text-primary mb-1">₹3,000+</div>
                  <div className="text-gray-700 text-sm">Average monthly savings per household</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ImpactSection;
